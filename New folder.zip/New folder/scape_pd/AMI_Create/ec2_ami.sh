#!/bin/bash

# // source the variables list //
source ./ec2_variables.sh

########################################// STEP 1 //#################################################################
# // get the AMI availability //
check_image=$(aws ec2 describe-images --region us-east-1 --image-ids ${Image} | jq -r .Images[].State)

# // check the AMI availability //
if [[ ${check_image} == available ]]; then
        echo "Image already exists, hence no need to create a new one"
        exit
else
        true
        echo " Above specified image doesn't exists in the list, hence going to create a new one for batch usage"
fi


#####################################// STEP 2 //#######################################################################
# // launch EC2 //
aws ec2 run-instances \
--image-id ${Image_Id} \
--count 1 \
--instance-type ${Instance_Type} \
--key-name ${Key_Name} \
--subnet-id ${Subnet_Id} \
--security-group-ids ${Security_Group} \
--iam-instance-profile Name=${Instance_Profile} \
--user-data file://user_data.txt \
--block-device-mappings file://ebs.json \
--tag-specifications 'ResourceType=instance, Tags=[{Key=Name,Value=NFS-BATCH-AMI-Instance},{Key=Project,Value=NFS},{Key=DeployedBy,Value=srinivasarao@corteva.com},{Key=ResourceOwner,Value=srinivasarao@corteva.com},{Key=Scheduled,Value=autoscale}]' > ./ec2_out.json

cat ./ec2_out.json
# // get the instance ID //
Instance_ID=$(jq -r .Instances[].InstanceId ./ec2_out.json)

####################################// STEP 3 //#########################################################################
# // wait for the instance to be running state // 
pending_status=$(aws ec2 describe-instances --instance-ids ${Instance_ID} | jq -r .Reservations[].Instances[].State.Name)
if [[ ${pending_status} == pending ]]; then
        true
        n=0
        while [[ "$n" -le 10 ]]
        r_status=$(aws ec2 describe-instances --instance-ids ${Instance_ID} | jq -r .Reservations[].Instances[].State.Name)
	s_status=$(aws ec2 describe-instance-status --instance-ids ${Instance_ID} | jq -r .InstanceStatuses[].InstanceStatus.Status)
        do
                n=$((n+1))
                echo "[waiting]: - waiting for instance to be running"
                echo "[OK]: $n interval now for ${Instance_ID} running check "
                sleep 30
                if  [[ ${r_status} == running ]] && [[ ${s_status} == ok ]] ;then
                        break
                fi
        done;
         echo "[OK]: ${Instance_ID} is running state now"
else
        echo "[OK]: ${Instance_ID} is already running"
fi

echo -e "[OK]: In order to take an AMI, we're going to stop the EC2 now"


###################################// STEP 4 //#############################################################################
# // stop the instance and wait for to stop it completely //
running_status=$(aws ec2 describe-instances --instance-ids ${Instance_ID} | jq -r .Reservations[].Instances[].State.Name)
if [[ ${running_status} == running ]]; then
        true
        aws ec2 stop-instances --instance-id ${Instance_ID}
        echo -e "[OK]: stopped the ${Instance_ID}"
        n=0
        while [[ "$n" -le 10 ]]
        change_status=$(aws ec2 describe-instances --instance-ids ${Instance_ID} | jq -r .Reservations[].Instances[].State.Name)
        do
                n=$((n+1))
                echo "[waiting]: - waiting for instance to be stopped"
                echo "[OK]: $n interval now for ${Instance_ID} stop check"
                sleep 30
                if  [[ ${change_status} == stopped ]];then
                        break
                fi
        done;
	echo "[OK]: ${Instance_ID} is stopped"
else
	echo "[OK]: ${Instance_ID} is already stopped"
fi

####################################// STEP 5 //##############################################################################
# // take the AMI of the instance //
stopped_status=$(aws ec2 describe-instances --instance-ids ${Instance_ID} | jq -r .Reservations[].Instances[].State.Name)
if [[ ${stopped_status} == stopped ]]; then
        true
	echo "[info]: NFS BATCH AMI is going to be create now"
        aws ec2 create-image \
	--instance-id ${Instance_ID} \
	--name "NFS-BATCH-AMI" \
	--description "An AMI for NFS BATCH" > ./Image_create.json
      
	cat Image_create.json
	Image_ID=$(jq -r .ImageId ./Image_create.json)
	n=0
        while [[ "$n" -le 30 ]]
	AMI_Status=$(aws ec2 describe-images --region us-east-1 --image-ids ${Image_ID} | jq -r .Images[].State)
	do
		n=$((n+1))
		echo "[waiting]: - waiting for AMI to be create & available state"
		echo "[OK]: $n interval now for ${Image_ID} creation"
		sleep 100
		if [[ ${AMI_Status} == available ]]; then
			break
		fi
	done;
	echo -e "[OK]: ${Image_ID} got created successfully"
else
	echo "Check your ${Instance_ID} status"
fi

############################// STEP 6 //################################################################################
# // Now EC2 is going to be delete //
AMI_Status=$(aws ec2 describe-images --region us-east-1 --image-ids ${Image_ID} | jq -r .Images[].State)
if [[ ${AMI_Status} == available ]]; then
	true
	echo "[info]: NFS BATCH AMI EC2 is going to terminate"
	aws ec2 terminate-instances --instance-ids ${Instance_ID}
	n=0
        whilei [[ "$n" -le 10 ]]
        t_status=$(aws ec2 describe-instances --instance-ids ${Instance_ID} | jq -r .Reservations[].Instances[].State.Name)
        do
                n=$((n+1))
                echo "[waiting]: - waiting for instance to be terminated"
                echo "[OK]: $n interval now for ${Instance_ID} deletion check"
                sleep 30
                if  [[ ${t_status} == terminated ]];then
                        break
                fi
        done;
	echo "[OK]: ${Instance_ID} has successfully terminated"
	rm ./Image_create.json
	rm ./ec2_out.json
	
fi
