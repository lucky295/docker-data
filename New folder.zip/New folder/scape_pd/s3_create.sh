#/bin/bash

NFS_BUCKET=$1
scape_dir=scape
pipeline_dir=pipeline
workspace_dir=WORKSPACE
referencedata_dir=REFERENCE_DATA

# // scape folder availability check, create if it not exists //
if [[ -z $(aws s3api head-bucket --bucket ${NFS_BUCKET}) ]]; then
	true
    echo "[OK]: ${NFS_BUCKET} exists"
	if [[ -z $(aws s3 ls s3://${NFS_BUCKET} | grep ${scape_dir}) ]]; then
		echo "${scape_dir} exists"
		aws s3 ls ${NFS_BUCKET}/ | grep ${scape_dir}
	else
		echo "${scape_dir} doesn't exist, hence going to create it for you"
		aws s3api put-object --bucket ${NFS_BUCKET} --key ${scape_dir}
		if [[ -z $(aws s3 ls s3://${NFS_BUCKET} | grep ${scape_dir}) ]]; then
			echo "${scape_dir} created successfully!"
			aws s3 ls ${NFS_BUCKET}/ | grep ${scape_dir}
		fi
	fi
# // pipeline folder availability check, create if it not exists //
	if [[ -z $(aws s3 ls s3://${NFS_BUCKET}/${scape_dir} | grep ${pipeline_dir}) ]]; then
		echo "${pipeline_dir} exists"
		aws s3 ls ${NFS_BUCKET}/${scape_dir}/ | grep ${pipeline_dir}
	else
		echo "${pipeline_dir} doesn't exist, hence going to create it for you"
		aws s3api put-object --bucket ${NFS_BUCKET} --key ${scape_dir}/${pipeline_dir}
		if [[ -z $(aws s3 ls s3://${NFS_BUCKET}/${scape_dir} | grep ${pipeline_dir}) ]]; then
			echo "${pipeline_dir} created successfully!"
			aws s3 ls ${NFS_BUCKET}/${scape_dir}/ | grep ${pipeline_dir}
		fi
	fi
# // workspace folder availability check, create if it not exists //
	if [[ -z $(aws s3 ls s3://${NFS_BUCKET}/${scape_dir} | grep ${workspace_dir}) ]]; then
		echo "${workspace_dir} exists"
		aws s3 ls ${NFS_BUCKET}/scape | grep ${workspace_dir}
	else
		echo "${workspace_dir} doesn't exist, hence going to create it for you"
		aws s3api put-object --bucket ${NFS_BUCKET} --key ${scape_dir}/${workspace_dir}
		if [[ -z $(aws s3 ls s3://${NFS_BUCKET}/${scape_dir} | grep ${workspace_dir}) ]]; then
			echo "${workspace_dir} created successfully!"
			aws s3 ls ${NFS_BUCKET}/scape | grep ${workspace_dir}
		fi
	fi
# // reference data folder availability check, create if it not exists //
	if [[ -z $(aws s3 ls s3://${NFS_BUCKET}/${scape_dir} | grep ${referencedata_dir}) ]]; then
		echo "${referencedata_dir} exists"
		aws s3 ls ${NFS_BUCKET}/scape | grep ${referencedata_dir}
	else
		echo "${referencedata_dir} doesn't exist, hence going to create it for you"
		aws s3api put-object --bucket ${NFS_BUCKET} --key ${scape_dir}/${referencedata_dir}
		if [[ -z $(aws s3 ls s3://${NFS_BUCKET}/${scape_dir} | grep ${referencedata_dir}) ]]; then
			echo "${referencedata_dir} created successfully!"
            aws s3 ls ${NFS_BUCKET}/scape | grep ${referencedata_dir}
		fi
	fi
else
    echo " ${NFS_BUCKET} doesn't exist"
fi


##
input_data
output_data
batch_workdir