#!/usr/bin/env bash

echo
echo -e "         =========================== "
echo "          N E X T F L O W ~ S C A P E "
echo -e "          ==========================="
echo

## // check input arguments //
if [[ "$#" -ne 1 ]]
then
        echo -e "[ERROR]: Please check the input arguements"
        echo -e "[COMMAND]: script.sh <input_json>"
        echo -e "[EXAMPLE]: scape.sh AK225.json"
        exit
else
        true
fi

# // Nextflow code path check and pull to container path //
S3_regex="^s3://"
S3_CODE_PATH=s3://sb-nfs/pipeline/scape/scape-code
PROJECT_DIR=/project_run

if [[ ${S3_CODE_PATH} =~ ${S3_regex} ]];
then
        true
        bucket_name=`echo ${S3_CODE_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        SDIR_NAME=`echo ${S3_CODE_PATH} | perl -pe 's#.*/(.*)#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${SDIR_NAME}/$")
        if [[ -z "$exists" ]]; then
                echo -e "[Error]: ${S3_CODE_PATH} does not exist in the s3 bucket"
                exit
        else
                true
                aws s3 cp ${S3_CODE_PATH}/pipeline_from_AWS_PSR ${PROJECT_DIR}/pipeline_from_AWS_PSR  --recursive
                aws s3 cp ${S3_CODE_PATH}/mail_list.sh ${PROJECT_DIR}/mail_list.sh
                aws s3 cp ${S3_CODE_PATH}/nf_log_s3_wrapper.sh ${PROJECT_DIR}/nf_log_s3_wrapper.sh
                echo -e "NF code has been pulled from s3"
        fi
fi


## // Input JOSN file exists in s3 path //
S3_JSON_PATH=s3://sb-nfs/pipeline/scape/INPUT_JSON

if [[ ${S3_JSON_PATH} =~ ${S3_regex} ]];
then
        true
        bucket_name=`echo ${S3_JSON_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        JDIR_NAME=`echo ${S3_JSON_PATH} | perl -pe 's#.*/(.*)#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${JDIR_NAME}/$")
        if [[ -z "$exists" ]]; then
                echo -e "[Error]: ${S3_JSON_PATH} does not exist in the s3 bucket"
                exit
        else
                true
                aws s3 cp ${S3_JSON_PATH}/$1 ${PROJECT_DIR}/INPUT_JSON/$1
                echo -e "Input JOSN has been pulled from s3"
        fi
fi

# // check local config file //
config_file=${PROJECT_DIR}/INPUT_JSON/$1

if [[ ! ( -f ${config_file} ) ]]; then
    echo  -e "input json file doesn't exists"
    exit
else
     true
fi


# // read the variables from json file //
se_or_pe_choice=($(jq -r '.NF_EXECUTION_TYPE.CHOICE' $config_file))
adapter_software_choice=($(jq -r '.ADAPTER_TRIMMING_SOFTWARE.CHOICE' $config_file))
contaminant_fasta=($(jq -r '.CONTAMINANT_FASTA.CHOICE' $config_file))
salmon_S3_folder_path=($(jq -r '.SALMON_INDEX_PATH.CHOICE' $config_file))
lims_id=($(jq -r '.LIMS_ID.CHOICE' $config_file))
tx2Gene_User_Input=($(jq -r '.TX2GENE_VAR.CHOICE' $config_file))
salmon_libtype=($(jq -r '.SALMON_LIBTYPE.CHOICE' $config_file))
trimq=($(jq -r '.TRIMQ.CHOICE' $config_file))
min_length=($(jq -r '.MIN_LENGTH.CHOICE' $config_file))
wanted_samples=($(jq -r '.SAMPLES.CHOICE' $config_file))
user_email=($(jq -r '.EMAIL.CHOICE' $config_file))

# // change to Upper Case - SE_PE_Choice, Salmon_LibType and LIMS_ID //
se_or_pe_choice="$(echo ${se_or_pe_choice} | tr  'a-z' 'A-Z')"
salmon_libtype="$(echo ${salmon_libtype} | tr  'a-z' 'A-Z')"
lims_id="$(echo ${lims_id} | tr  'a-z' 'A-Z')"

## // print json input //
echo "Pipeline parameters input by the user is as follows..."
echo
echo "NF_EXECUTION_TYPE is: ${se_or_pe_choice[@]}"
echo "LIMS_ID IS: ${lims_id[@]}"
echo "WANTED_SAMPLES: ${wanted_samples[@]}"
echo "CONTAMINANT_FASTA is: ${contaminant_fasta[@]}"
echo "TRIMQ IS: ${trimq[@]}"
echo "MIN_LENGTH IS: ${min_length[@]}"
echo "ADAPTER_TRIMMING_SOFTWARE_CHOICE is: ${adapter_software_choice[@]}"
echo "SALMON_INDEX_PATH is: ${salmon_S3_folder_path[@]}"
echo "SALMON_LIBTYPE IS: ${salmon_libtype[@]}"
echo "TX2GENE_VAR is: ${tx2Gene_User_Input[@]}"
echo "EMAIL is: ${user_email[@]}"
echo


# \\ get the user from the email \\
USER=(${user_email%%.*})
echo ${USER}

# \\ salmon s3 path \\
if ! [[ "${salmon_S3_folder_path}" =~ (\/)$ ]]; then
    echo -e "SALMON_INDEX_PATH:${salmon_S3_folder_path} - Missing Forward slash at the very end - No worri
es, we will add it for you"
    salmon_S3_folder_path=${salmon_S3_folder_path}'/'
fi


S3_regex="^s3://"

# // START - QC Checks - Type 1 - Program to Exit //

# // Check 1 - is LIMS_ID of the form 2 Alphabets followed by 3 numbers //

regexLIMS='^[A-Z]{2}[0-9]{3}$'

if ! [[ ${lims_id} =~ ${regexLIMS} ]] ; then
    echo -e "[ERROR]: ${lims_id} format is WRONG\nCorrect format of PROJECT_ID is 2 Alphabets followed by 3 numbers\nExample AK311"
    echo -e "EXITTING"
    exit
fi

# // Check 2 - Is it SE or PE //

if ! [[ "${se_or_pe_choice}" =~ ^(SE|PE)$ ]]; then
    echo -e "[ERROR]: $se_or_pe_choice is INVALID\nValid Options: SE or PE"
    echo -e "EXITTING"
    exit
fi

# // Check 3 - Make sure versionInfo.json is available of the salmon_S3_folder_path //
if [[ ${salmon_S3_folder_path} =~ ${S3_regex} ]];
then
        true
        file_name="versionInfo.json"
        exists=$(aws s3 ls ${salmon_S3_folder_path} | grep ${file_name})
        if [[ -z "$exists" ]]; then
            echo "${file_name} file does not exist, Please declare the correct s3 path for salmon_index_path in vars_json file"
            echo "Make sure you have used salmon 1.2.0 for creating salmon index - please check ${file_name} contents"
            echo -e "EXITTING"
            exit
        else
# // Check 4 - If versionInfo.json is available, then parse the json and make sure it is 1.2.0, else exit //
            versionFile=$(date +"%Y%m%d_%H%M%S")_`whoami`.txt
            tmpPath="/project_run/${versionFile}"
            wanted_version='^1.2'

            aws s3 cp  ${salmon_S3_folder_path}versionInfo.json  ${tmpPath}  --quiet
            salmon_Index_Version=$( cat ${tmpPath} | jq '.salmonVersion' | perl -pe 's#"##g' )
            # // echo -e "versionInfo.json has Index Version as $salmon_Index_Version" //

            if  [[ ${salmon_Index_Version} =~ ${wanted_version} ]]; then
                rm -f  ${tmpPath}
            else
# // this is not 1.2.0 or 1.2.1 or anything with 1.2, we have to exit
                #echo  -e "Strings are NOT equal\t$wanted_version - Wanted salmon Version\t$salmon_Index_Version - from salmon" //
                echo "Make sure you have used salmon 1.2.0 or above for creating salmon index - please check ${file_name} contents"
                echo -e "EXITTING"
                rm -f  ${tmpPath}
                exit
            fi
        fi
else
        echo -e "[ERROR]: Please declare the correct S3 bucket path for salmon_index_path in vars_json file"
        echo -e "Note: Enter the full S3 path where salmon_index_path is available – example s3://sb-nfs/scape/REFERENCE_DATA/maize/ED85E/TXOME_IND
EX/"
        exit
fi


# // Check 5 - Make sure wanted_samples file exists in S3 if defined with S3 path //
if [[ ${wanted_samples} =~ ${S3_regex} ]];
then
    true
    bucket_name=`echo ${wanted_samples} | perl -pe 's#(.*)/.*#$1#g'`
    file_name=`echo ${wanted_samples} | perl -pe 's#.*/(.*)#$1#g'`
    exists=$(aws s3 ls --recursive ${bucket_name} | grep "${file_name}$")
    if [[ -z "$exists" ]]; then
        echo "${wanted_samples} - This DOES NOT Exist in the S3 Location"
        echo "${file_name} file doesn't exist, Please declare the correct s3 path for SAMPLES in the JSON config file"
        echo "Example: s3://sb-nfs/scape/WORKSPACE/batch_workdir/wanted_samples.txt"
        echo -e "EXITTING"
        exit
    else
        true
    fi
fi

# // Check 6 - Make sure tx2Gene exists in S3 if defined with S3 path //
if [[ ${tx2Gene_User_Input} =~ ${S3_regex} ]];
then
    bucket_name=`echo ${tx2Gene_User_Input} | perl -pe 's#(.*)/.*#$1#g'`
    file_name=`echo ${tx2Gene_User_Input} | perl -pe 's#.*/(.*)#$1#g'`
    exists=$(aws s3 ls --recursive ${bucket_name} | grep "${file_name}$")
    if [ -z "$exists" ]; then
        echo "${tx2Gene_User_Input} - This DOES NOT Exist in the S3 Location"
        echo "${file_name} file does not exist, Please declare the correct s3 path for tx2gene in the JSON config file"
        echo "Example: s3://sb-nfs/scape/REFERENCE_DATA/maiize/ED85E/ED85E_ERCC.tx2gene.tsv"
        echo -e "EXITTING"
        exit
    else
        true
    fi
fi

# // Check 7 - Make sure contaminant fasta file exists in S3 //
if [[ ${contaminant_fasta} =~ ${S3_regex} ]];
then
    true
    bucket_name=`echo ${contaminant_fasta} | perl -pe 's#(.*)/.*#$1#g'`
    file_name=`echo ${contaminant_fasta} | perl -pe 's#.*/(.*)#$1#g'`
    exists=$(aws s3 ls --recursive ${bucket_name} | grep "${file_name}$")
    if [[ -z "$exists" ]]; then
        echo "${contaminant_fasta} - This DOES NOT Exist in the S3 Location"
        echo "${file_name} file doesn't exist, Please declare the correct s3 path for contaminant_fasta in vars_json file"
        echo "Example: s3://sb-nfs/scape/REFERENCE_DATA/maize/zm.rRNA.C.M.fa"
        echo -e "EXITTING"
        exit
    else
        true
    fi
else
    echo "Please upload your contaminant fasta file to relevant s3 folder"
    echo "Example: s3://sb-nfs/scape/REFERENCE_DATA/maize/zm.rRNA.C.M.fa"
    echo -e "EXITTING"
    exit
fi

# // END - QC Checks - Type 1 - Program to Exit //

# // START - QC Checks - Type 2 - Check defaults //

adapter_software_choice="$(echo ${adapter_software_choice} | tr  'A-Z' 'a-z')"

if ! [[ "${adapter_software_choice}" =~ ^(bbduk|fastp)$ ]]; then
    echo -e "${adapter_software_choice} is NOT a valid option for ADAPTER_TRIMMING_SOFTWARE\tReverting to bbduk as default"
    adapter_software_choice="bbduk"
fi

# // trimQ and minLength check //

regexNumber='^[0-9]+$'
if ! [[ ${trimq} =~ ${regexNumber} ]] ; then
    echo -e "trimQ: ${trimq} is NOT an integer\nDefaulting it to 20"
    trimq="20"
fi

if ! [[ ${min_length} =~ ${regexNumber} ]] ; then
    echo -e "minLength: ${min_length} is NOT an integer\nDefaulting it to 35"
    min_length="35"
fi

# // Valid choices for Salmon LibType
# https://salmon.readthedocs.io/en/latest/library_type.html#fraglibtype
# ISF, ISR, IU, MSF, MSR, MU, OSR, OSF, OU, U, SR, SF, A //
if ! [[ "${salmon_libtype}" =~ ^(ISF|ISR|IU|MSF|MSR|MU|OSR|OSF|OU|U|SR|SF|A)$ ]]; then
    echo -e "salmon_libtype: $salmon_libtype is INVALID\tDefaulting to A"
    echo -e "Please check https://salmon.readthedocs.io/en/latest/library_type.html#fraglibtype"
    salmon_libtype="A"
    echo -e "We will use salmon_libtype = ${salmon_libtype} in the pipeline"
fi

# // END - QC Checks - Type 2 - Check defaults
# START - QC Checks to find out Salmon LIBTYPE compatibility with SE/PE //
if  [[ "${se_or_pe_choice}" =~ ^(SE)$ ]]; then

    if ! [[ "${salmon_libtype}" =~ ^(A|U|SR|SF)$ ]]; then
        echo -e "===========ERROR DETECTED==============================="
        echo -e "salmon_libtype: ${salmon_libtype} is INVALID with $se_or_pe_choice"
        echo -e "Possible Valid Choices are: SR, SF, U, A"
        echo -e "Please check https://salmon.readthedocs.io/en/latest/library_type.html#fraglibtype"
        echo -e "EXITTING"
        echo -e "===========ERROR DETECTED==============================="
        exit
    fi

fi

if  [[ "${se_or_pe_choice}" =~ ^(PE)$ ]]; then

    if ! [[ "${salmon_libtype}" =~ ^(A|ISF|ISR|IU|MSF|MSR|MU|OSR|OSF|OU)$ ]]; then
        echo -e "===========ERROR DETECTED==============================="
        echo -e "salmon_libtype: ${salmon_libtype} is INVALID with ${se_or_pe_choice}"
        echo -e "Possible Valid Choices are: ISF, ISR, IU, MSF, MSR, MU, OSR, OSF, OU, A"
        echo -e "Please check https://salmon.readthedocs.io/en/latest/library_type.html#fraglibtype"
        echo -e "EXITTING"
        echo -e "===========ERROR DETECTED==============================="
        exit
    fi

fi

# // END  - QC Checks to find out Salmon LIBTYPE compatibility with SE/PE //
if [[ ${wanted_samples} =~ ${S3_regex} ]];
then
    SAMPLES_WANTED="--include_samples_file '"${wanted_samples}"'"
else
    SAMPLES_WANTED=""
fi


if [[ ${tx2Gene_User_Input} =~ ${S3_regex} ]];
then
    TX2GENE_PATH="--tx2gene_file '"${tx2Gene_User_Input}"'"
else
    TX2GENE_PATH=""
fi

echo -e "\nINPUT QC CHECKS PASSED"

# // Declare variables //
NOW=$(date +"%Y%m%d_%H%M%S")
# // Declare variables //
nextflow_code=/project_run/pipeline_from_AWS_PSR
nextflow_home=/home/${USER}/pipeline_from_AWS_PSR
echo
if [[ ! -d ${nextflow_home} ]]; then
        true
        echo " ${nextflow_home} doesn't exists, hence we're going to create it for you"
        mkdir -p ${nextflow_home}
        cp -rf ${nextflow_code}/* ${nextflow_home}/
        echo "SCAPE code has been copied successfully to pipeline execution path"
        cd ${nextflow_home}
else
        rm -rf ${nextflow_home}/*
        cp -rf ${nextflow_code}/* ${nextflow_home}/
        echo "SCAPE code has been copied successfully to pipeline execution path"
        cd ${nextflow_home}

fi


# // Define adapter_trimming_software_choice //

adapter_trimming_software_choice="${adapter_software_choice[@]}"
adapter_trimming_software_choice="$(echo ${adapter_trimming_software_choice} | tr  'A-Z' 'a-z')"

if ! [[ "$adapter_trimming_software_choice" =~ ^(bbduk|fastp)$ ]]; then
    echo -e "$adapter_trimming_software_choice is NOT a valid choice\nReverting to bbduk as default"
   adapter_trimming_software_choice="bbduk"
fi

# // check the input & output data folders in users space //
# // Create them if they not exist //
i_base=scape/WORKSPACE/input_data
o_base=scape/WORKSPACE/output_data
w_base=scape/WORKSPACE/batch_workdir
i_space=s3://sb-nfs/${i_base}
o_space=s3://sb-nfs/${o_base}
w_space=s3://sb-nfs/${w_base}
U_Input_PATH=${i_space}/$USER
U_Output_PATH=${o_space}/$USER
U_Workdir_PATH=${w_space}/$USER
if [[ $U_Input_PATH =~ $S3_regex ]];
then
    true
    bucket_name=`echo ${U_Input_PATH} | perl -pe 's#(.*)/.*#$1#g'`
    IDIR_NAME=`echo ${U_Input_PATH} | perl -pe 's#.*/(.*)#$1#g'`
    exists=$(aws s3 ls --recursive $bucket_name | grep "${IDIR_NAME}/$")
    if [ -z "$exists" ]; then
        echo -e "[Note]: ${U_Input_PATH} does not exist in the s3 bucket, hence creating it"
        aws s3api put-object --bucket sb-nfs --key ${i_base}/${USER}/
    else
        true
    fi
fi

if [[ ${U_Output_PATH} =~ ${S3_regex} ]];
then
    true
    bucket_name=`echo ${U_Output_PATH} | perl -pe 's#(.*)/.*#$1#g'`
    ODIR_NAME=`echo ${U_Output_PATH} | perl -pe 's#.*/(.*)#$1#g'`
    exists=$(aws s3 ls --recursive ${bucket_name} | grep "${ODIR_NAME}/$")
    if [[ -z "$exists" ]]; then
        echo -e "[Note]: ${U_Output_PATH} does not exist in the s3 bucket, hence creating it"
        aws s3api put-object --bucket sb-nfs --key ${o_base}/${USER}/
    else
        true
    fi
fi

if [[ ${U_Workdir_PATH} =~ ${S3_regex} ]];
then
    true
    bucket_name=`echo ${U_Workdir_PATH} | perl -pe 's#(.*)/.*#$1#g'`
    WDIR_NAME=`echo ${U_Workdir_PATH} | perl -pe 's#.*/(.*)#$1#g'`
    exists=$(aws s3 ls --recursive $bucket_name | grep "${WDIR_NAME}/$")
    if [[ -z "$exists" ]]; then
        echo -e "[Note]: ${U_Workdir_PATH} does not exist in the s3 bucket, hence creating it"
        aws s3api put-object --bucket sb-nfs --key ${w_base}/${USER}/
    else
        true
    fi
fi

# // variables to use in the script //
WORK_DIR_PATH=s3://sb-nfs/scape/WORKSPACE/batch_workdir/${USER}
RESULT_DIR_PATH=s3://sb-nfs/scape/WORKSPACE/output_data/${USER}

# // Launching job //
SE_PE_PARAM=""

if [[ ${se_or_pe_choice} == "SE" ]];
then
    SE_PE_PARAM=" --singleEnd "
fi

# // Start execution //
RUN_CMD="$(cat <<VAREOF
    nextflow run main.nf  ${SE_PE_PARAM}  --LIMS_ID ${lims_id} \
    ${SAMPLES_WANTED}  ${TX2GENE_PATH} \
    --s3_input_fastq_timestamp ${NOW}  \
    --trimQ ${trimq} --minLength ${min_length} \
    --contaminant_software bbmap \
    --contaminant_fasta '${contaminant_fasta}' \
    --adapter_software ${adapter_trimming_software_choice} \
    --salmon_index_path '${salmon_S3_folder_path}' \
    --quant_method salmon  \
    --salmon_libtype ${salmon_libtype} \
    -w '${WORK_DIR_PATH}/${NOW}_${se_or_pe_choice}' \
    --outdir '${RESULT_DIR_PATH}/${NOW}_${se_or_pe_choice}' \
    -name ${USER}_${NOW}_${se_or_pe_choice} \
    --email ${user_email} \
    -profile awsbatch
VAREOF
    )"

echo "${RUN_CMD}"
eval ${RUN_CMD}

sleep 5
echo

# \\ nextflow log file upload to s3 \\
# \\ Wrapper to upload .nextflow.log \\
RUN_WRAPPER="$(cat <<WRAPPER
    /project_run/nf_log_s3_wrapper.sh \
    ${nextflow_home}/.nextflow.log \
    ${RESULT_DIR_PATH}/${NOW}_${se_or_pe_choice}
WRAPPER
    )"

echo "=========================Nextflow SCAPE Wrapper========================="
echo
echo "Hope you had a great SCAPE experience"