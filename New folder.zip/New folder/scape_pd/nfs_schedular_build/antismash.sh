#!/usr/bin/env bash


echo
echo -e "         =========================== "
echo "             N E X T F L O W ~ FIND "
echo -e "          ==========================="
echo

##check input arguments
if [[ "$#" -ne 1 ]]
then
        echo -e "[ERROR]: Please check the input arguements"
        echo -e "[COMMAND]: script.sh <input_json>"
        echo -e "[EXAMPLE]: antismash.sh test.json"
        exit
else
        true
fi
#Nextflow code path check and pull to container path
S3_regex="^s3://"
S3_CODE_PATH=s3://sb-nfs/pipeline/find/find-code
PROJECT_DIR=/project_run
NOW=$(date +"%Y%m%d_%H%M%S")

#create a new folder to use it for job execution
if [[ -d ${PROJECT_DIR} ]]
then
    true
    echo -e "${PROJECT_DIR} exists, so please go ahead and create a pipeline execution directory"
    mkdir -p ${PROJECT_DIR}/${NOW}_find
else
    echo -e "${PROJECT_DIR} doesn't exists"
    exit
fi

EXECUTION_DIR=${PROJECT_DIR}/${NOW}_find
#check the find s3 code and download it to pipeline execution directory

if [[ ${S3_CODE_PATH} =~ $S3_regex ]];
then
        true
        bucket_name=`echo ${S3_CODE_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        SDIR_NAME=`echo ${S3_CODE_PATH} | perl -pe 's#.*/(.*)#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${SDIR_NAME}/$")
        if [[ -z "$exists" ]]; then
                echo -e "[Error]: ${S3_CODE_PATH} does not exist in the s3 bucket"
                exit
        else
                true
                aws s3 cp ${S3_CODE_PATH}/pipeline_code ${EXECUTION_DIR}/pipeline_code  --recursive
                aws s3 cp ${S3_CODE_PATH}/mail_list.sh ${EXECUTION_DIR}/mail_list.sh
                echo -e "NF code has been pulled from s3"
        fi
fi


## Input JOSN file exists in s3 path
S3_JSON_PATH=s3://sb-nfs/pipeline/find/INPUT_JSON

if [[ ${S3_JSON_PATH} =~ $S3_regex ]];
then
        true
        bucket_name=`echo ${S3_JSON_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        JDIR_NAME=`echo ${S3_JSON_PATH} | perl -pe 's#.*/(.*)#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${JDIR_NAME}/$")
        if [[ -z "$exists" ]]; then
                echo -e "[Error]: ${S3_JSON_PATH} does not exist in the s3 bucket"
                exit 0
        else
                true
                aws s3 cp ${S3_JSON_PATH}/$1 ${EXECUTION_DIR}/INPUT_JSON/$1
                echo -e "Input JOSN has been pulled from s3"
        fi
fi

#check local config file
config_file=${EXECUTION_DIR}/INPUT_JSON/$1

if [[ ! ( -f ${config_file} ) ]]; then
    echo  -e "input json file doesn't exists"
    exit 0
else
     true
fi


# read the variables from json file
INPUT_DATA=($(jq -r '.INPUT_DATA_FOLDER' ${config_file}))
USER=($(jq -r '.USER' ${config_file}))

##print json input
echo
echo "Pipeline parameters input by the user is as follows..."
echo "INPUT_DATA_FOLDER is: ${INPUT_DATA[@]}"
echo "USER IS: ${USER[@]}"
echo "$USER"


# Check the input arguements
if [[ "$#" -ne 1 ]]
then
        echo -e "[ERROR]:Please check the arguements"
        echo -e "[COMMAND_HELP]: <script.sh> <s3_input_dir> EXAMPLE: ./run_antismash.sh test"
        echo -e "[NOTE]: make sure that the s3_input_dir is exists in the correct s3 path"
        echo -e "EXITTING"
        exit
else
        true
fi

#input dir check
S3_regex="^s3://"
i_base=find/WORKSPACE/input_data
i_space=s3://sb-nfs/${i_base}
U_Input_PATH=${i_space}/${USER}

if [[ ${U_Input_PATH} =~ ${S3_regex} ]];
then
        bucket_name=`echo ${U_Input_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${INPUT_DATA}")
        if [[ -z "$exists" ]]; then
                echo -e "[ERROR]:${U_Input_PATH}/${INPUT_DATA} does not exist in the s3 bucket"
                echo -e "EXITTING"
                exit
        else
                true
                echo "${U_Input_PATH}/${INPUT_DATA} exists"
        fi
fi

# check find nextflow code and copy it to pipeline execution path
nextflow_code=${EXECUTION_DIR}/pipeline_code
nextflow_home=/home/${USER}/${NOW}_pipeline_code
echo
if [[ ! -d ${nextflow_home} ]]
 then
        echo -e "[WARNING]: ${nextflow_home} doesn't exists, hence we're going to create it for you"
        mkdir -p ${nextflow_home}
        cp -rf ${nextflow_code}/* ${nextflow_home}/
        echo -e "FIND code has been copied successfully to pipeline execution path"
        cd ${nextflow_home}
else
        rm -rf ${nextflow_home}/*
        rm -rf ${nextflow_home}/.nextflow
        rm -rf ${nextflow_home}/.nextflow.log*
        cp -rf ${nextflow_code}/* ${nextflow_home}/
        echo -e "FIND code has been copied successfully to pipeline execution path successfully"
        echo
        cd ${nextflow_home}
fi

#check the input & output data folders in users space
# Create them if they not exists
o_base=find/WORKSPACE/output_data
w_base=find/WORKSPACE/batch_workdir
o_space=s3://sb-nfs/${o_base}
w_space=s3://sb-nfs/${w_base}
U_Output_PATH=${o_space}/${USER}
U_Workdir_PATH=${w_space}/${USER}

#output path check
if [[ ${U_Output_PATH} =~ $S3_regex ]];
then
        bucket_name=`echo ${U_Output_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        ODIR_NAME=`echo ${U_Output_PATH} | perl -pe 's#.*/(.*)#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${ODIR_NAME}/$")
        if [[ -z "$exists" ]]; then
                echo -e "[Note]: ${U_Output_PATH} does not exist in the s3 bucket, hence creating it"
                aws s3api put-object --bucket sb-nfs --key ${o_base}/${USER}/
        else
                true
        fi
fi

#workdir path check
if [[ ${U_Workdir_PATH} =~ $S3_regex ]];
then
        bucket_name=`echo ${U_Workdir_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        WDIR_NAME=`echo ${U_Workdir_PATH} | perl -pe 's#.*/(.*)#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${WDIR_NAME}/$")
        if [[ -z "$exists" ]]
        then
                echo -e "[Note]: ${U_Workdir_PATH} does not exist in the s3 bucket, hence creating it"
                aws s3api put-object --bucket sb-nfs --key ${w_base}/${USER}/
        else
                true
        fi
fi

#USER=scape
NOW=$(date +"%Y%m%d_%H%M%S")
I_PATH=${U_Input_PATH}/${INPUT_DATA}
O_PATH=${U_Output_PATH}
W_PATH=${U_Workdir_PATH}
GENE=*_genomic.fna

echo
echo "your logged in user is $USER and pipeline is executed by $USER"

# User email notification
chmod +x ${EXECUTION_DIR}/mail_list.sh
source ${EXECUTION_DIR}/mail_list.sh
mail_list="srini anand shravan"
name=${USER}
eval 'echo $'${name} > /tmp/${USER}.txt
email="$( cat /tmp/${USER}.txt )"

for mail in ${mail_list}
do
        if [[ ${mail} == ${USER} ]]; then
                true
                user_email="${email}"
                echo -e "user is ${USER}\nExecution/Completion status will be sent as email to - ${user_email}"
                echo
        fi
done;

#submit the pipeline
nextflow run main.nf \
--input  ${I_PATH}/${GENE} \
-w ${W_PATH}/${NOW}_FIND \
--outdir ${O_PATH}/${NOW}_FIND \
-name ${USER}_${NOW}_FIND \
--email ${user_email} \
-profile awsbatch
