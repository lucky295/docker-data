#!/usr/bin/env Python

animals = ['man', 'bear', 'pig']
#animals = ['man', 'bear', 'pig', 'cat']
try:
    cat_index = animals.index('cat')
except:
    cat_index = 'No cats found'
print (cat_index)
