#!/usr/bin/env Python

animals = ['man', 'bear', 'pig', 'cow', 'duck', 'horse']

index = 0

while index < len(animals):
	print (animals[index])
	index += 1
