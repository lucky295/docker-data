#!/usr/bin/env Python

sum = 2 + 1
difference = 100 - 1
product = 3 * 4
quotient = 8 / 2
power = 2 ** 4
reminder = 3 % 2

print ('sum: {}'.format(sum))
print ('Difference: {}'.format(difference))
print ('Product: {}'.format(product))
print ('Quotient: {}'.format(quotient))
print ('Power: {}'.format(power))
print ('Reminder: {}'.format(reminder))


#int() function

print()
q_string = '3'
total = int(q_string) + 2
print (total)


"""  Hello """
