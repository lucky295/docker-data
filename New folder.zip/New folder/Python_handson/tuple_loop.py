#!/usr/bin/env Python


weekend_days = ('Saturday', 'Sunday')
for day in weekend_days:
	print (day)

#tuples assign variable values
(sat, sun) = weekend_days

print ()
print (sat)
print (sun)


print ()
contact_info = ['555-0123', 'jason@example.com']
(phone, email) = contact_info

print (phone)
print (email)
