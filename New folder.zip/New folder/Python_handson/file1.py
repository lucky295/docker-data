#!/usr/bin/env Python

with open ('file.txt') as the_file:
	for line in the_file:
		print (line)

with open ('file.txt') as the_file:
	for line in the_file:
		print (line.rstrip())


print ()
with open ('file.txt') as the_file:
	print (the_file.mode)


print ()
