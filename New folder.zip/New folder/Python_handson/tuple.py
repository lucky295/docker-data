#!/usr/bin/env Python

days_of_the_week = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')

print ()
monday = days_of_the_week[0]
print (monday)
print ()

for day in days_of_the_week:
	print (day)


print ()
print (days_of_the_week)
del days_of_the_week

#this wil raise an exception
print ()
print (days_of_the_week)
