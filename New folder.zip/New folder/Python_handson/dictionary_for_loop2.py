#!/usr/bin/env Python

contacts = {
    'Jason': {
        'phone': '555-0123',
        'email': 'jason@example.com'
    },
    'Carl': {
        'phone': '555-0987',
        'email': 'carl@example.com'
    }
}


for contact in contacts:
    print ()
    print ("{}'s contact info:" .format(contact))
    print (contacts[contact]['phone'])
    print (contacts[contact]['email'])
    print ()
