#!/usr/bin/env Python

if 37 < 40:
	print ('Thirty-seven is less than 40')

print ();

age = 31

if age >= 35:
    print ('You are old enough to be the President.')
else:
    print ('You are not old enough to be the President.')    

print ('Have a nice day.!!')
