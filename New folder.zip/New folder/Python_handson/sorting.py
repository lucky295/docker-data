#!/usr/bin/env Python


animals = ['man', 'bear', 'pig']
sorted_animals = sorted(animals)

print ()
print ('Animals list: {}'.format(animals))

print ()
print ('Sorted animals list: {}'.format(sorted_animals))

animals.sort()
print ()
print ('Animals after sort method: {}'.format(animals))
