#!/usr/bin/env Python

import time
#time.method_name()
#time.attribute_name()


print ()
print (time.asctime())
print (time.timezone)



print ()
from time import asctime
print (asctime())


from time import asctime, sleep

print (asctime())

sleep (3)

print (asctime())


#

from time import *

print ()
print (timezone)
print (asctime())
sleep (3)
print (asctime())
