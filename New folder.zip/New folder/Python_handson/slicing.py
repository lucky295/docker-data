#!/usr/bin/env Python


animals = ['man', 'bear', 'pig', 'cow', 'duck', 'hourse']
print (animals)

print()
some_animals = animals[1:4]
print ('Some animals:  {}'.format(some_animals))


print()
first_two = animals[0:2]
print ('First two animals: {}'.format(first_two))

print ()
first_two_again = animals[:2]
print ('First two animals: {}'.format(first_two_again))

print()
last_two = animals[4:6]
print ('Last two animals: {}'.format(last_two))


print ()
last_two_again = animals[-2:]
print ('Last two animals: {}'.format(last_two))


print()
part_of_a_horse = 'horse'[1:3]
print (part_of_a_horse)
