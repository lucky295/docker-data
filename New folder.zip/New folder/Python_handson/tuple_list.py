#!/usr/bin/env Python

weekend_tuple = ('Saturday', 'Sunday')
weekend_list = list(weekend_tuple)

print ()
print ('weekend_tuple is {}.'.format(type(weekend_tuple)))
print ('weekend_list is {}.'.format(type(weekend_list)))


animals_list = ['man', 'bear', 'pig']
animals_tuple = tuple(animals_list)

print ()
print ('animals_list is {}.'.format(type(animals_list)))
print ('animals_tuple is {}.'.format(type(animals_tuple)))
