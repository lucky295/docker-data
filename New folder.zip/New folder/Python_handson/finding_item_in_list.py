#!/usr/bin/env Python


animals = ['man', 'bear', 'pig']
bear_index = animals.index('bear')
print (bear_index)

print ()
man_index = animals.index('man')
print (man_index)

print ()
pig_index = animals.index('pig')
print (pig_index)

print ()
print ('Length of animals:{}'.format(len(animals)))
