#!/usr/bin/env Python

def say_hi():
    print ('Hi!')

say_hi ()


# type 1
print ()
def say_hello(name):
    print ('Hi {}!'.format(name))

say_hello ('Srinivas')
say_hello ('Everyone')

#type 2
print ()
def say_hello2(first, last):
    print ('Hi {} {}!'.format(first, last))

say_hello2 ('Srinivas', 'Annapareddi')

# type 3
print ()
def say_hello3(first, last):
    print ('Hi {} {}!'.format(first, last))

say_hello3 (first = 'Srinivas', last = 'Annapareddi')

# type 4
print ()

def say_hello4(first, last='Annapareddi'):
    print ('Hi {} {}!'.format(first, last))

say_hello4 ('Srinivas')
say_hello4 ('Srinivas', 'Annapareddi')
