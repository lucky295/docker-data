#!/usr/bin/env Python

def high_and_low(numbers):
	"""Determine the highest and lowest number"""
	highest = max(numbers)
	lowest = min(numbers)
	return (highest, lowest)


lottery_numbers = [16, 4, 42, 15, 23, 8]
(highest, lowest) = high_and_low(lottery_numbers)
print ('The highest number is {}'.format(highest))
print ('The lowest number is {}'.format(lowest))



contacts = [('Jason', '555-0123'), ('Carl', '555-0987')]
print ()
for (name, phone) in contacts:
	print ("{}'s phone number is {}.".format(name, phone))


my_tuple = (1)
my_tuple1 = (2,)

print (my_tuple)
print (my_tuple1)
