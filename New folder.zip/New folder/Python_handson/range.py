#!/usr/bin/env Python

for number in range (3):
    print (number)

print ()
for number in range (1, 3):
    print (number)

print ()
for number in range (1, 10, 2):
    print (number)

#
print ()

animals = ['man', 'bear', 'pig', 'cow', 'duck', 'horse', 'dog']

for number in range (0, len(animals), 2):
    print (animals[number])

list = [3, 4, 5, 6, 5]
print (len(list))
