#!/usr/bin/env Python

animals = ['man', 'bear', 'pig']

more_animals = ['cow', 'duck', 'horse']

all_animals = animals + more_animals
print (all_animals)

print ()
print ('All animals from both lists: {}'.format(all_animals))

print ()
print ('Length of all animals from both lists: {}'.format(len(all_animals)))

print ()
print ('First animal from all animals: {}'.format(animals[0]))


print ()
print (len(animals))

print ()
animals.append('cow')
print (len(animals))
