#!/usr/bin/env python


contacts = {'Jason': '555-0123', 'Carl': '555-0987'}
Jasons_phone = contacts['Jason']
Carls_phone = contacts['Carl']

print ()
print ('Dial {} to call Jason.'.format(Jasons_phone))

print ()
print ('Dial {} to call Carl.'.format(Carls_phone))


contacts['Jason'] = '555-0000'
Jasons_phone = contacts['Jason']

print ()
print ('Dial {} to call Jason.'.format(Jasons_phone))

#add item to the dictionary
print()
contacts['Tony'] = '555-0570'
print (contacts)
print (len(contacts))

# delete item from the dictionary

print ()

del contacts['Jason']
print (contacts)

#

contacts = {
	'Jason': ['555-0123', '555-0000'],
	'Carl': '555-0987'
}

print ()
print (contacts)
print ('Jason')
print (contacts['Jason'])
print('Carl:')
print (contacts['Carl'])

print ()
for number in contacts['Jason']:
	print ('Phone: {}'.format(number))


print ()
if 'Jason' in contacts.keys():
	print ("Jason's phone number is:")
	print (contacts['Jason'][0])

print ()
if 'Tony' in contacts.keys():
	print ("Tony's phone number is: ")
	print (contacts['Yony'][0])

print ()
print ('555-0987' in contacts.values())
