#!/usr/bin/env python

print ('hello')

print ("hello")

sentence = 'she said, "That is great testing apple!"'
sentence1 = "she said, 'That is great testing apple!'"
print (sentence)
print (sentence1)

fruit = 'apple'
print (fruit)
print ('orange')

# method
print (len(fruit));
print (fruit.upper())

# String concatenation
print ('I ' + 'Love ' + 'Python. ')
print ('I' + ' Love' + ' Python.')

first = 'I'
second = 'Love'
third = 'Python'

check = first + ' ' + second + ' ' + third + '.'

print (check)


happiness = 'happy ' * 3
print (happiness)

# The str() Function
version = 3
print ('I Love Python ' + str(version) + '.')


#formatting strings

print ('I {} Python.'.format('love'))

print ('{} {} {}'.format('I', 'Love', 'Python.'))


print ('I {0} {1}.  {1} {0}s me'.format('Love', 'Python'))

print ('{} {} {}'.format(first, second, third))

print ('I Love Python {}'.format(version))

print()
print('{0:8} | {1:8}'.format('Fruit', 'Quantity'))

print('{0:8} | {1:8}'.format('Apple', 3))

print('{0:8} | {1:8}'.format('Oranges', 10))

print()
print('{0:8} | {1:<8}'.format('Fruit', 'Quantity'))

print('{0:8} | {1:<8}'.format('Apple', 3))

print('{0:8} | {1:<8}'.format('Oranges', 10))


print()
print('{0:8} | {1:<8}'.format('Fruit', 'Quantity'))

print('{0:8} | {1:<8.2f}'.format('Apple', 2.33333))

print('{0:8} | {1:<8.2f}'.format('Oranges', 10))

print()
x = input('Prompt to display: ')
print ('Input value from user is {}.'.format(x))



print()
fruit = input('Enter a name of a fruit: ')
print ('{} is a lovely fruit.'.format(fruit))


############========== excercise 1 =======================#####################
print()
animal = 'cat'
vegitable = 'brocoli'
mineral = 'gold'

print ('Here is an {}, a {}, and a {}'.format('animal', 'vegitable', 'mineral'))
print (animal)
print (vegitable)
print (mineral)


############===================excercise 2================

print()
user_input = input('Please type something and press enter: ')
print('You entered:')
print(user_input)


############===================excercise 2================
print()
text = input('what would you like the cat to say?')
text_length = len(text)

print ('         {}'.format('_' * text_length))
print ('<        {} >'.format(text))
print ('         {}'.format('_' * text_length))
print ('         /')
print (' /\_/\   /')
print ('( o o )')
print (' > ^ <')
