#!/usr/bin/env python

contacts = {
	'Jason': '555-0123',
	'Carl': '555-0987'
}

print ()
for contact in contacts:
	print ('The number for {0} is {1}.'.format(contact, contacts[contact]))


print ()

for person, phone_number in contacts.items():
	print (' The number for {0} is {1}.'.format(person, phone_number))
