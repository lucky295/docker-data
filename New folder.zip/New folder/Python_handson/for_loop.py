#!/usr/bin/env Python

animals = ['man', 'bear', 'pig']

print ()
for animal in animals:
    print (animal.upper())
