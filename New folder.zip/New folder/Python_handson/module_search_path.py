#!/usr/bin/env Python

import sys
sys.path


for path in sys.path:
    print (path)


#

print ()
import sys
file_name = 'file.txt'
try:
	with open (file_name) as test_file:
		for line in test_file:
			print (line)
except:
	print ('Could not open {}.'.format(file_name))
	sys.exit(1)

#

def say_hi():
    print('Hi!')

import say_hi
say_hi.say_hi()
