#!/usr/bin/env Python

def say_hello(first, last='Annapareddi'):
    """ Say Hello. """
    print ('Hi {} {}!'.format(first, last))

help(say_hello)


# odd or Even

""" Commenting this
def odd_or_even(number):
    if number % 2 == 0:
        return 'Even'
    else:
        return 'Odd'

odd_or_even_string = odd_or_even(7)
print (odd_or_even_string) """

# odd or Even

def is_odd(number):
    """ Determine if a number is odd or even """
    if number % 2 == 0:
        return  False
    else:
        return True

#odd_or_even_string = odd_or_even(7)
print (is_odd(7))


#
print ()
def get_name():
    name = input('What is your name? ')
    return name

def say_name(name):
    print ('Your name is {}.'.format(name))

def get_and_say_name():
    """ Get and Display name"""
    name = get_name()
    say_name(name)

get_and_say_name()
