#!/usr/bin/env Python

x = int(input ("Enter the value of x: "))
y= int(input("Enter the second value: "))

sum = x + y
difference = x - y
product = y * y
quotient = x / y
power = x ** y
reminder = x % y

print ("sum:", sum)
print ("Difference:", difference)
print ("Product:", product)
print ("Quotient:", quotient)
print ("Power:", power)
print ("Reminder:", reminder)
