#!/usr/bin/env Python

#Open a file and assign it's contents to a variable.
#If the file i un available, create an emapty variable.

try:
	contacts = open ('contacts.txt').read()
except:
	contacts = ''
    
print (len(contacts))
