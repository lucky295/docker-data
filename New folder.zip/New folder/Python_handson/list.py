#!/usr/bin/env Python


animals = ['man', 'bear', 'pig']
print (animals[0])

print ()
animals[0] = 'cat'
print(animals[0])


print()
animals.append('cow')
print (animals[-1])

#------ extend items
print ()
animals = ['man', 'bear', 'pig']
animals.extend(['cow', 'duck'])
print (animals)

more_animals = ['horse', 'dog']
animals.extend(more_animals)
print (animals)

#---------insert item into position
print()
animals = ['man', 'bear', 'pig']
animals.insert(0, 'horse')
print (animals)

animals.insert(2, 'duck')
print (animals)
