#!/usr/bin/env bash

# colour define
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
mag=`tput setaf 6`
blue=`tput setaf 4`
bold=$(tput bold)
reset=`tput sgr0`

declare LOCAL_PATH=$(pwd)/logs
declare LOG_GROUP=/aws/batch/job

#check the local LOG folder path exists
if ! [[ -d ${LOCAL_PATH} ]]
then
    echo -e "[ERROR]:${red}${bold}${LOCAL_PATH} doesn't exists in your execution path ${reset}"
    exit 0
else
    true
    echo "${green}${bold}${LOCAL_PATH} exists ${reset}"
fi

#get the job_id
JOB_ID=$(jq -r .jobId ${LOCAL_PATH}/job_id.json)
echo
echo "${green}${bold}JOB_ID is: $JOB_ID ${reset}"

#get the job status of the given job id
aws batch describe-jobs \
--jobs ${JOB_ID} > ${LOCAL_PATH}/job_status.json

#get the logstream value
LOG_STREAM=$(jq -r .jobs[].container.logStreamName ${LOCAL_PATH}/job_status.json)
echo
echo "${green}${bold}LOG_STREAM is: $LOG_STREAM ${reset}"

#get the job status
JOB_STATUS=$(jq -r .jobs[].status ${LOCAL_PATH}/job_status.json)
echo
echo "${green}${bold}JOB_STATUS is: $JOB_STATUS ${reset}"

#check the status and get the logs info
if [[ ${JOB_STATUS} == RUNNABLE ]]; then
    echo
    echo "${yellow}${bold}Your pipeline schedular is RUNNABLE state, Please wait for a while ${reset}"
elif [[ ${JOB_STATUS} == STARTING ]]; then
    echo "${yellow}${bold}BATCH schedular is about to start ${reset}"
elif [[ ${JOB_STATUS} == RUNNING ]]; then
    echo
    echo "dp-name ${LOG_GROUP} \
    --log-stream-name ${LOG_STREAM} > ${LOCAL_PATH}/logs.json

    tail -40 ${LOCAL_PATH}/logs.json
elif [[ ${JOB_STATUS} == SUCCESS ]]; then
    echo
    echo "${green}${bold}Your pipeline got SUCCESS ${reset}"
    aws logs get-log-events \
    --log-group-name ${LOG_GROUP} \
    --log-stream-name ${LOG_STREAM} > ${LOCAL_PATH}/logs.json

    tail -40 ${LOCAL_PATH}/logs.json
else
    echo
    echo "${red}${bold}Your pipeline got FAILED ${reset}"
    aws logs get-log-events \
    --log-group-name ${LOG_GROUP} \
    --log-stream-name ${LOG_STREAM} > ${LOCAL_PATH}/logs.json

    tail -40 ${LOCAL_PATH}/logs.json
fi