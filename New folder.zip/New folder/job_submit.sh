#!/usr/bin/env bash

#define two input dynamic variables which takes from user
declare INPUT_JSON=$1
declare JOB_NAME=$2

NOW=$(date +"%Y%m%d_%H%M%S")
JSON_FILE=${NOW}_${INPUT_JSON}
echo "${JSON_FILE}"

##check input arguments
if [[ "$#" -ne 2 ]]
then
        echo -e "[ERROR]: Please check the input arguments"
        echo -e "[COMMAND]: script.sh <input_json>"
        echo -e "[EXAMPLE]: scape.sh AK225.json"
        exit 0
else
        true
fi

#define the S3 json location
declare S3_JSON_PATH=s3://sb-nfs/HAWK/INPUT_JSON
declare LOCAL_PATH=$(pwd)
declare LOG_PATH=${LOCAL_PATH}/logs

#check the local LOG folder path exists
if ! [[ -d ${LOG_PATH} ]]
then
    echo "${LOG_PATH} doesn't exists in your execution path, hence going to create it for you"
    mkdir ${LOG_PATH}
else
    echo "${LOG_PATH} exists"
fi

#check if the S3 json path is correct format, and upload input json to s3
if [[ ${S3_JSON_PATH} =~ $S3_regex ]];
then
        true
        bucket_name=`echo ${S3_JSON_PATH} | perl -pe 's#(.*)/.*#$1#g'`
        LJDIR_NAME=`echo ${S3_JSON_PATH} | perl -pe 's#.*/(.*)#$1#g'`
        exists=$(aws s3 ls --recursive ${bucket_name} | grep "${LJDIR_NAME}/$")
        if [[ -z "$exists" ]]; then
                echo -e "[Error]: ${S3_JSON_PATH} does not exist in the s3 bucket"
                exit 0
        else
                true
                aws s3 cp ${LOCAL_PATH}/${INPUT_JSON} ${S3_JSON_PATH}/${JSON_FILE}
                echo -e "${JSON_FILE} has been uploaded to s3"
        fi
fi

#batch info
declare JOB_QUEUE=HAWK-Spot-Batch-Queue
declare JOB_DEFINITION=nfs-schedular-definition

#submit the schedular batch now
aws batch submit-job \
--job-queue ${JOB_QUEUE} \
--job-definition ${JOB_DEFINITION} \
--job-name ${JOB_NAME} \
--container-overrides command="scape.sh","${JSON_FILE}" > ${LOG_PATH}/job_id.json